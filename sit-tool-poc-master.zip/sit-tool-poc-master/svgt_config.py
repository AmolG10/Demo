
#TBD - as of now this file contains 'tentative' config params. this file consolidates all config constants / hardcoded stuffs for single point code change.
#params which need customization capability without causing code change, move them into non-code config files. like
#uc_catagory_list, category_testrun_dict, cmparam_masterlist, ucparam_cmparam_dict

import os
import pandas as pd

#svgt project root path
svgt_root_path = os.path.dirname(os.path.realpath('__file__'))

#output variation testrun files dir path
#TBD - for every execution, create a dir under output as timestamp to store variation files
#TBD - create timestamp dir in var_testrun_filename (line 147) from svgt_testrun_writer.py
output_var_path = os.path.join(svgt_root_path, 'output')

#unused
#database files  dir path
db_path = os.path.join(svgt_root_path, 'database')

#unused
#base testrun / use case / scenario files database dir path
db_testrun_path = os.path.join(db_path, 'db_testrun')

#unused
#road files database dir path
db_road_path = os.path.join(db_path, 'db_road')

#unused
#vehicle files database dir path
db_vehicle_path = os.path.join(db_path, 'db_vehicle')

#unused
#output log files dir path
#TBD - for every execution, create a log file as timestamp.log to record info (all input, temp and output info)
#timestamp folder under output dir and timestamp.log should give sufficient info needed for debuging / recreate issue / investigation analysis purpose in case of errors
output_log_path = os.path.join(svgt_root_path, 'log')

#unused
#TBD - auto populate it through program - yyyymmddhhmmss
timestamp = "get invocation timestamp"

#unused
#base use case / scenario category list
#TBD - extend this list
uc_catagory_list=['CCRs','CCRm','CCRb','CCSCTIE','CCLTA']
vehicle_name_list=['BMW_5_BMWBrake','BMW_5_FSF500','Conti_Vehicles_CMC','TBD3']

#unused
#key value pairs to hold base use case / scenario categories and relevant testrun file names
#TBD - obtain base use case / scenario testrun files for all cases
category_base_testrun_dict = {'CCRs':'CCRs_50p_vEgo_30kph_vTar_0kph_ID_818',
                         'CCSCTIE':'CCSCTIE_vEgo_10kph_vTar_10kph_ID_45812',
                         'CCLTA':'CCLTA_25p_Vego_20kph_Vtar_30kph_r14_75_ID_102860_new',
                         'CCRm':'TBD1',
                         'CCRb':'TBD2'}

#usage. remove after refactoring check_selected_category()
#testrun = svgt_config.category_base_testrun_dict.pop(category)

#TBD - rewrite check_selected_category() using config or move it to config and set Testrunfilepath (or input_base_testrun_path
#or create set_input_base_testrun_path(category)
#input_base_testrun_path = input_base_testrun_db_path + "/" + category_base_testrun_dict.pop(input_category)
#input_base_testrun_path = input_base_testrun_db_path + "/" + svgt_config.category_base_testrun_dict.pop(input_category)

#unused
#CarMaker UAQ (User Accessible Quantities) parameters / signals master list
#TBD - extend this list to include all signals that appear in testrun files and for which variation creation will be supported by svgt
#NOTE - this list does not mean exhaustive list of all carmaker signals as not every signal can be varied through svgt
#NOTE - do not confuse this list with 'fixed' & 'variable' types found in scenario definition input file. 'fixed' param in one input file can be 'variable' in another one
cmparam_masterlist = ["Vehicle",
                "DrivMan.Init.Velocity",
                "DrivMan.0.LongDyn",
                "DrivMan.1.LongDyn",
                "Traffic.T00.ty",
                "Traffic.0.Init.Orientation",
                "TBD",
                "TBD",
                "TBD"]

#unused
#base use case / scenario params from requirements to CarMaker UAQ parameters / signals mapping - key, value pairs  dictionary
#TBD - extend this list to include all params that appear in req csv files and for which variation creation will be supported by svgt
ucparam_cmparam_dict = {'v_ego':'DrivMan.Init.Velocity',
                         'overlap':'Traffic.T00.ty',
                         'rotation':'Traffic.0.Init.Orientation',
                         'TBD1':'TBD2'}

#unused
#create new df for scenario  definition params input file rows. unused
scenario_df_cols=['ScenarioID', 'ReqID', 'Category','ParameterDescription','Parameter','ParameterType','Value','Unit','CMParam','Min','Max','Step','AppendValue']
scenario_df = pd.DataFrame(columns=scenario_df_cols)

#unused
#create new df for variation range params . unused.
variation_range_df_cols=['Min', 'Max', 'Step']
variation_range_df = pd.DataFrame(columns=variation_range_df_cols)

#unused
#create new df for variation params . unused.
variation_df_cols=['ScenarioID','Category','Parameter','Unit','CMParam','VarNum','VarVal']
variation_df = pd.DataFrame(columns=variation_df_cols)

#unused
#create new df for requirement csv params . unused.
reqparam_df_cols=['UC_INDEX','UC_SCTAG_ID','UC_SCTAG_NAME','UC_PAR_ID_NAME','UC_PAR0_NAME','UC_PAR1_NAME','TBD1','TBD2']
reqparam_df = pd.DataFrame(columns=reqparam_df_cols)




