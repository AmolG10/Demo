from enum import IntEnum

# this will get extended a lot for many params so keeping it in separate file
#returns formatted variation param value for received param name
def prep_var_param_format(param_name, param_value):

    if param_name == 'DrivMan.Init.Velocity':
        param_value = param_value

    if param_name == 'DrivMan.0.LongDyn':
        Driv_longdy = " Driver 1 0 " + str(param_value)
        param_value = Driv_longdy

    if param_name == 'DrivMan.1.LongDyn':
        Driv_longdy = " Driver 1 0 " + str(param_value)
        param_value = Driv_longdy

    # TBD - handle overlap which is not multiple of 25. like 10, 20, etc
    # TBD - replace below class with some other data structure -  why not dict?
    class percentage(IntEnum):
        OVERLAP_0_P = 0
        OVERLAP_25_P = 25
        OVERLAP_50_P = 50
        OVERLAP_75_P = 75

    # create values for overlap
    overlap_values_list = [0, "Car.ty-Car.Width_m/-4", "Car.ty-Car.Width_m/-2", "3*Car.ty-Car.Width_m/-4","Car.ty-Car.Width_m"]

    if param_name == 'Traffic.T00.ty':
        if param_value == percentage.OVERLAP_0_P:
            param_value = overlap_values_list[0]
        elif param_value == percentage.OVERLAP_25_P:
            param_value = overlap_values_list[1]
        elif param_value == percentage.OVERLAP_50_P:
            param_value = overlap_values_list[2]
        elif param_value == percentage.OVERLAP_75_P:
            param_value = overlap_values_list[3]
        else:
            param_value = overlap_values_list[4]

    if param_name == 'Traffic.0.Init.Orientation':
        rotation_value = ' 0.0 0.0 -' + str(param_value)
        param_value = rotation_value

    # print("inside",param_name,param_value)
    return param_name, param_value
