# SIT Tool POC

POC for basic operations in SIT tool

###repo info:
- **database** -  database folder containing:   
- **db_testrun** - base testrun / use case / scenario files  
- **db_road** - road files  
- **db_vehicle** - vehicle files  
- **input** - sample scenario definition input file(s)  
- **output** - container for this tool created variation testrun files  
  
main.py - main entry  
  
_Model files_:  
svgt_config.py  
svgt_model.py  
svgt_var_param_format.py  
svgt_testrun_writer.py  
  
_View files_:  
svgt_view.py  
  
_Controller files_:  
svgt_controller.py  
  
###execution info:  
below command (optional) can be used for execution.  
'**python3 -X pycache_prefix=../bytecodes main.py**'  
where:  
**bytecodes** is a folder one level up from  main.py path.  
**pycache_prefix** option moves "compiled bytecode" / *.pyc files 
that gets created in \__pycache__\ folder out of source code directory structure.
for more info refer [pycache_prefix](https://howchoo.com/python/python-pycache-prefix)