from svgt_model import SvgtModel
from svgt_view import SvgtView
from PySide6.QtWidgets import QFileDialog

class SvgtController:
	
 def __init__(self):
    self.view=SvgtView()
    self.model=SvgtModel()
    self.vehicle_name=""
    self.view.pushbutton_inputfile.clicked.connect(self.provide_scenario_des_file_path)
    self.view.pushbutton_roadfile.clicked.connect(self.provide_road_file_path)
    self.view.pushbutton_outfolder.clicked.connect(self.provide_output_path)
    self.view.pushbutton_generate.clicked.connect(self.click_generate)
    self.view.combo_box_Vehtype.currentTextChanged.connect(self.insert_vehicle_name)
    
 def insert_vehicle_name(self, vehicle_name):
    if vehicle_name:
       self.model.get_vehicle_name(vehicle_name)
    else:
       print("select vehicle name")
       
 def provide_road_file_path(self):
    road_file , check = QFileDialog.getOpenFileName(None, "QFileDialog.getOpenFileName()","", "All Files (*);;Python Files (*.py);;Text Files (*.txt)")
    self.view.line_roadfile.setText('{}'.format(road_file))
    if road_file:
       self.model.get_road_file(road_file)
    else:
       print("select Road file")
    
 def provide_scenario_des_file_path(self):
    Infile , check = QFileDialog.getOpenFileName(None, "QFileDialog.getOpenFileName()","", "All Files (*);;Python Files (*.py);;Text Files (*.txt)")
    self.view.line_inputfile.setText('{}'.format(Infile))
    folder_path=Infile
    if folder_path:
       self.model.get_data_from_scenario_description(folder_path)
       self.model.check_selected_category()
    else:
       print("select scenario description file")
       
 def provide_output_path(self):
    output_path = str(QFileDialog.getExistingDirectory())
    self.view.line_outfolder.setText('{}'.format(output_path))
    if output_path:
       self.model.get_output_path_from_ui(output_path)
    else:
       print("select output folder")
 
 def click_generate(self):
    self.model.create_variations()  
