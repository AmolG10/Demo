import os
import sys
import pandas as pd
import openpyxl
import itertools
from enum import IntEnum
from pprint import pprint
from svgt_view import display_variation_status
from svgt_testrun_writer import Testrun_Writer

#TBD - rename this file as svgt_variation_creator.py
#TBD - rename SvgtModel class as Variation_Creator as current name not proper descriptive name for this class - does not provide any idea about purpose of the class

class SvgtModel:
 def __init__(self):
    self.output_path = ""
    self.input_file = ""
    self.Category_Name = ""
    self.vehicle_name ="Demo_Car"
    self.selected_roadfile=" "
 def get_output_path_from_ui(self,path):
    self.output_path=path
       
 def get_vehicle_name(self,veh_name):
    self.vehicle_name= veh_name
    if self.vehicle_name == "":
       self.vehicle_name="Demo_Car"
        #raise SystemExit('Exception: Invalid vehicle type selected')
           #print("Error: Invalid vehicle type selected")
           #sys.exit(1)
        
    
 def get_road_file(self,road_file):
    self.selected_roadfile= road_file
    road_parameter=["ErrorClass.11.WarningLimit","Road.FName","Road.VhclStartPos","Road.VhclRoute","Road.RouteId"]
    parameter_value=[" ","10 0 0","Route_0","0"]
    parameter_value[0]=self.selected_roadfile
    with open(self.Testrunfilepath, "r") as f1:
        lines = f1.readlines()
    f1.close()
    if self.selected_roadfile:
        self.testrunfile_road_param=self.Testrunfilepath+"_new"
        print("test run file:",self.testrunfile_road_param)
        print("Roadfile is present in the folder and roadfile quantities are added")
        with open(self.testrunfile_road_param, "w") as f:
            for line in lines:
                x = ["Road.2Movie","Road.VhclStartPos","Road.Lane","Road.Dig","Road.Country","Road.RouteId","Road.GCS","Road.Definition","IPGRoad","Default","Origin","Straight"]
                y = line.strip("\n")
                if not x[0] in y and not x[1] in y and not x[2] in y and not x[3] in y and not x[4] in y and not x[5] in y and not x[6] in y and not x[7] in y and not x[8] in y and not x[9] in y and not x[10] in y and not x[11] in y:
                    f.write(line)
        f.close()
        
        with open(self.testrunfile_road_param, 'r+') as fd:
            contents = fd.readlines()
            for i in range(0,4):
                if road_parameter[i] in contents[-1]:  # Handle last line to prevent IndexError
                    contents.write(road_parameter[i+1])
                else:
                    for index, line in enumerate(contents):
                        if road_parameter[i] in line and road_parameter[i + 1] not in contents[index + 1]:
                            print(road_parameter[i])
                            contents.insert(index + 1, road_parameter[i + 1]+" = "+parameter_value[i]+"\n")
                            break
            fd.seek(0)
            fd.truncate()
            fd.writelines(contents)

        fd.close()
        self.Testrunfilepath=self.testrunfile_road_param
    else:
        print("Roadfile is not present in the Folder Path")


 def get_data_from_scenario_description(self,input_file):
    self.input_file=input_file
    try:
       self.df = pd.read_csv(input_file)
       self.df.fillna('', inplace=True)
       self.Row = self.df.shape[0]  # finding total rows
       self.Col = self.df.shape[1]  # finding total columns
       if self.Row == 0 and self.Col == 0:
            raise SystemExit("Row and Col value is 0. Load correct input file")
    except ValueError:
        print("Sheet Name is wrong. correct the sheet name")
    # forward fill using previous value to fill in empty cells for below columns
    self.df['ScenarioID'] = self.df['ScenarioID'].ffill()
    self.df['ReqID'] = self.df['ReqID'].ffill()
    self.df['Category'] = self.df['Category'].ffill()

  
 def check_selected_category(self):
    Testrunfilepath=""
    fileDir = os.path.dirname(os.path.realpath('__file__'))
    base_scenarios_path = os.path.join(fileDir, 'database', 'db_testrun')
    self.relative_path_base_scenarios = os.path.relpath(base_scenarios_path, fileDir)
    catagory_list=['CCRs','CCRm','CCRb','CCSCTIE']
    for row in range(0, self.Row):
        excel_values = []
        excel_row_list = []
        for col in range(self.Col):
            excel_values = (self.df.iloc[row, col])
            if col >= 1:
                excel_row_list.append(excel_values)
        if excel_row_list[1] in catagory_list:
            self.category_name=excel_row_list[1]
            if self.category_name == 'CCRs':
                self.Testrunfilepath = os.path.join(self.relative_path_base_scenarios,"CCRs_50p_vEgo_30kph_vTar_0kph_ID_818")
            elif self.category_name == 'CCSCTIE':
                self.Testrunfilepath = os.path.join(self.relative_path_base_scenarios,"CCSCTIE_vEgo_10kph_vTar_10kph_ID_45812")
            elif self.category_name == 'CCRm': 
                self.Testrunfilepath = os.path.join(self.relative_path_base_scenarios,"CCRm_p50p_vEgo_50kph_vTar_20kph_FCW_ID_1106")
            elif self.category_name == 'CCRb':
                self.Testrunfilepath = os.path.join(self.relative_path_base_scenarios,"CCRb_50kph_40m_6mpss_ID_397")
            else:
                print("category not present")
   

 def populate_variations_in_df(self,variations_list,df_for_ScenarioID):
    var_df_cols = list(df_for_ScenarioID['CMParam'])
    #create variation df using variations_list (carmaker param names and their values)
    variation_df = pd.DataFrame(variations_list, columns=var_df_cols)

    var_sequence_number = 0
    #iterate over variations_list to create variation number
    for combination in variations_list:                                                     #combination = (80,100,30)
        var_sequence_number = var_sequence_number + 1
        var_number_str = "var" + str(var_sequence_number)       #var135

        for item in combination:                                                                        #item = 80
            var_number_str = var_number_str + "_" + str(item)           #var135_80_100_30

        #add & populate variation number column into variation df
        variation_df.loc[var_sequence_number - 1,"VarNum"] = var_number_str
        #print("var_number_str", var_number_str)

    #add & populate Category and ScenarioID columns into variation df
    variation_df['Category'] = df_for_ScenarioID.iloc[0]['Category']
    variation_df['ScenarioID'] = df_for_ScenarioID.iloc[0]['ScenarioID']

    #['DrivMan.Init.Velocity', 'Traffic.T00.ty', 'Traffic.0.Init.Orientation','VarNum', 'Category',ScenarioID' ]
    #changing dataframe column order from (sample) above to below format
    #['ScenarioID', 'Category', 'VarNum', 'DrivMan.Init.Velocity', 'Traffic.T00.ty', 'Traffic.0.Init.Orientation']
    cols = list(variation_df)
    cols = [cols[-1]] + [cols[-2]] + [cols[-3]] + cols[:-3]
    #print(cols)
    variation_df = variation_df[cols]

    ##add & populate variation file name column into variation df
    variation_df.insert(loc = 3,
              column = 'VarFileName',
              value = variation_df['ScenarioID'] + "_" + variation_df['Category'] + "_" + variation_df['VarNum'] )      #Sce_123_CCRs_var135__80_100_30

    #pprint(variation_df)
    return variation_df

 def create_variations(self):
   #TBD - why this check is here? this function doesnt use self.input_file
   if self.input_file == "":
        display_variation_status("Variation Creation is Unsuccessful: Input SD file is not loaded")
        raise SystemExit("Exception: Input SD file is not loaded")
   elif self.output_path == "":
        display_variation_status("Variation Creation is Unsuccessful: Output Path is not selected")
        raise SystemExit("Exception: Select Output Path")
   else:
    #iterate over ScenarioID groups list - input file can have multiple scenario IDs
    for i in list(self.df.groupby('ScenarioID').groups.keys()):
        #create mask for ScenarioID to filter df to get rows only for specific ScenarioID
        mask_ScenarioID = self.df['ScenarioID'] == i
        df_for_ScenarioID = self.df[mask_ScenarioID]
        #copy only min, max and step columns into another df
        df_for_ScenarioID_3cols = df_for_ScenarioID[['Min', 'Max', 'Step']].copy()
        #increament Max by Step as range function needs it that way to work correctly
        #df_for_ScenarioID_3cols['Max'] = df_for_ScenarioID_3cols['Max'] + df_for_ScenarioID_3cols['Step']

        #block to create range list to create variations
        variation_range_list = []
        #param_max = [5]
        #i=0
        for row in range(0, df_for_ScenarioID_3cols.shape[0]):
            #obtain mix, max and step for 1 row
            param_min = (df_for_ScenarioID_3cols.iloc[row, 0])
            #print("input min value:",param_min)
            if param_min =="":
               display_variation_status("Variation Creation is Unsuccessful : Min value is not present in SD Input File")
               raise SystemExit("Exception: Min value is not present")
            param_max = (df_for_ScenarioID_3cols.iloc[row, 1])
            #print("param_max:",param_max)
            if param_max =="":  
               display_variation_status("Variation Creation is Unsuccessful : Max value is not present in SD Input File")
               raise SystemExit("Exception: Max value is not present")
            param_step = (df_for_ScenarioID_3cols.iloc[row, 2])
            if param_step =="":
               display_variation_status("Variation Creation is Unsuccessful : Step value is not present in SD Input File")
               raise SystemExit("Exception: Step value is not present")
            # create range list for 1 row of df
            param_min =int(param_min)
            param_max =int(param_max)
            param_step =int(param_step)
            variation_range = [*range(param_min,param_max+1,param_step)]
            # append range list to create list of lists
            variation_range_list.append(variation_range)
            #print(param_min,param_max,param_step)

        #print(variation_range_list)
        variations = list(itertools.product(*variation_range_list))
        #pprint(variations)

    variations_df = self.populate_variations_in_df(variations,df_for_ScenarioID)
    testrun_writer_obj = Testrun_Writer()
    testrun_writer_obj.write_variations_in_testrun_files(variations,variations_df,df_for_ScenarioID,self.Testrunfilepath,self.vehicle_name,self.selected_roadfile)
    flag=True
   return flag