import os
from enum import IntEnum
import svgt_config as svgtconfig
import svgt_var_param_format as svgtvarparamformat

#TBD - dont make it as class if there are no data members but instead it has only methods
class Testrun_Writer:

    def create_variation_testrun_using_base_testrun(self,base_testrun_filename,variation_testrun_filename):
        #TBD - use input_base_testrun_path from config or not ?
        with open(base_testrun_filename, "r") as read_only:
            if os.path.isfile(variation_testrun_filename):
                print("File already exists")
                #TBD - check if error handling to exit is needed here or not
                #print('.', end='')         #write . in single line to avoid scrolling up in cmd window
            else:
                with open(variation_testrun_filename, "w") as output:
                    for line in read_only:
                        output.write(line)

    def update_created_testrun_file(self,var_testrun_file_name,parameter_name,parameter_value):
        output_testrun_file = open(var_testrun_file_name, 'r+')
        content_lines = []

        for line in output_testrun_file:
                if parameter_name in line:
                   if '=' in line:
                        line_components = line.split('=')
                        if type(parameter_value) == str:
                            line_components[1] = parameter_value +'\n'
                        else:
                            line_components[1] = str(parameter_value) +'\n'
                        updated_line= "=".join(line_components)
                        content_lines.append(updated_line)
                   else:
                     print(parameter_name,":parameter is not present in testrun file")
                else:
                        content_lines.append(line)

        output_testrun_file.seek(0)
        output_testrun_file.truncate()
        output_testrun_file.writelines(content_lines)

    #TBD - reduce input params to this function
    def write_variations_in_testrun_files(self,variations,variations_df,df_for_ScenarioID,base_testrun_filename,vehicle_name,roadfile_path):
        
        var_testrun_filename = ""
        formatted_param_name = ""
        formatted_param_value = ""
        formatted_param_name1 = ""
        formatted_param_value1 = ""
        formatted_param_name2 = ""
        formatted_param_value2 = ""
        cmparam_masterlist = ["Vehicle",
                "DrivMan.Init.Velocity",
                "DrivMan.0.LongDyn",
                "DrivMan.1.LongDyn",
                "Traffic.T00.ty",
                "Traffic.0.Init.Orientation"]
        # sample var_df_cols = ['ScenarioID','Category','VarNum','VarFileName','DrivMan.Init.Velocity','Traffic.T00.ty','Traffic.0.Init.Orientation']
        for row in range(0, variations_df.shape[0]):
            for col in range(3, variations_df.shape[1]):                        #starting from VarFileName column onwards
                # obtain variation param name and value for 1 row
                var_param_name = variations_df.columns[col]         #VarFileName
                var_param_value = variations_df.iloc[row, col]          #Sce_123_CCRs_var1_0_0_10
                #if column name is VarFileName then set var_file_name and null var_param_name & var_param_value
                if var_param_name == 'VarFileName':
                    #TBD - create timestamp dir here to store var testrun files from every execution
                    var_testrun_filename = os.path.join(svgtconfig.output_var_path, var_param_value) # create complete variation file path
                    var_param_name = ""
                    var_param_value = ""
                    #create variation testrun file as copy of base testrun / use case / scenario file
                    #TBD -  rewrite check_selected_category() to set Testrunfilepath
                    self.create_variation_testrun_using_base_testrun(base_testrun_filename, var_testrun_filename)
                    #TBD - eliminate below
                    #self.create_file_name = var_testrun_filename

                #for variation param name, get formatted  (for updating in variation testrun file) variation param value
                if var_param_name != '':
                    #print("var_param_name:",var_param_name)
                    #print("var_param_value:",var_param_value)
                    if var_param_name == 'DrivMan.Init.Velocity':
                       formatted_param_name1, formatted_param_value1 = svgtvarparamformat.prep_var_param_format('DrivMan.0.LongDyn', var_param_value)
                       formatted_param_name2, formatted_param_value2 = svgtvarparamformat.prep_var_param_format('DrivMan.1.LongDyn', var_param_value)
                     
                    #formatted_param_name, formatted_param_value = self.prep_var_param_format(var_param_name, var_param_value)
                    formatted_param_name, formatted_param_value = svgtvarparamformat.prep_var_param_format(var_param_name, var_param_value)

                #update variation param name and formatted  variation param value in variation testrun file
                if formatted_param_name != '':
                    if formatted_param_value != '':
                        self.update_created_testrun_file(var_testrun_filename,formatted_param_name, formatted_param_value)
                if formatted_param_name1 != '':
                    if formatted_param_value1 != '':
                        self.update_created_testrun_file(var_testrun_filename,formatted_param_name1, formatted_param_value1)
                if formatted_param_name2 != '':
                    if formatted_param_value2 != '':
                        self.update_created_testrun_file(var_testrun_filename,formatted_param_name2, formatted_param_value2)

                #TBD - confirm why LongDyn was added in previous code?

                #update vehicle name  in variation testrun file
                #TBD - get vehicle_name from config
                self.update_created_testrun_file(var_testrun_filename,'Road.FName ', roadfile_path)
                self.update_created_testrun_file(var_testrun_filename,'Vehicle ', vehicle_name)
