from PySide6 import QtCore, QtGui,QtWidgets
from PySide6.QtWidgets import QFileDialog, QMainWindow, QWidget, QLabel, QLineEdit,QComboBox,QPushButton,QMessageBox
import sys
import os
#from svgt_model import SvgtModel

def databasebasescenario():

	fileDir = os.path.dirname(os.path.realpath('__file__'))
	base_scenarios_path = os.path.join(fileDir, 'database', 'db_testrun')
	relative_path_base_scenarios = os.path.relpath(base_scenarios_path, fileDir)

	# checking if the directory is empty  

	if len(os.listdir(relative_path_base_scenarios) ) == 0:
		return True
	else:
		return False	

def display_basescenarions_alert():

	base_scenarios_alert = QMessageBox()
	base_scenarios_alert.setWindowTitle("BaseScenarios")
	base_scenarios_alert.setText("Directory is Empty ! Please place the base scenario files")
	base_scenarios_alert.exec()
    
def display_variation_status(string):

	created_variation_status = QMessageBox()
	created_variation_status.setWindowTitle("    Variation Status    ")
	created_variation_status.setText(string)
	created_variation_status.exec()    
    
class SvgtView(QMainWindow):

	def __init__(self):	
		 QMainWindow.__init__(self)
		 vehicle_list=[]
		 self.vehicle_name=""
        # setting title
		 self.setWindowTitle("SVGT")  
        # setting geometry
		 self.setGeometry(500, 500, 700, 700)
        # calling method
		 self.create_ui()
        #showing all the widgets
		 self.show()
       
    # method for widgets
	def create_ui(self):
		#creating Vehicle type combo box widget
		self.combo_box_Vehtype = QComboBox(self)
		self.namelabel_Vehtype = QLabel(self)
		self.namelabel_Vehtype.setText('Select VehicleType:')
		self.namelabel_Vehtype.resize(200, 32)
		self.namelabel_Vehtype.move(10, 50)
		
		# setting Vehtype geometry of combo box
		self.combo_box_Vehtype.setGeometry(200, 55, 50, 50)

		# list of vehicles
		vehicle_list = ["Demo_Car","Conti_Vehicles_CMC/BMW_5_FSF500", "BMW_5_BMWBrake ","Vehicle3", "Vehicle4"]

		# making it editable
		self.combo_box_Vehtype.setEditable(True)
		
		# adding list of items to combo box
		self.combo_box_Vehtype.addItems(vehicle_list)
        
		# adjusting the size according to the maximum sized element
		self.combo_box_Vehtype.adjustSize()
		
		#bush button for select SD file
		self.pushbutton_inputfile = QPushButton('Select', self)
		self.pushbutton_inputfile.resize(25,120)
		self.pushbutton_inputfile.move(425, 153) 
		self.pushbutton_inputfile.adjustSize()
		
		#bush button for select SD file text alignment
		self.namelabel_inputfile = QLabel(self)
		self.namelabel_inputfile.setText('Scenario Description Input File:')
		self.line_inputfile = QLineEdit(self)
		self.line_inputfile.move(200, 150)
		self.line_inputfile.resize(200, 32)
		self.namelabel_inputfile.move(10, 150)
		self.namelabel_inputfile.adjustSize()
        
        #push button for selection of output folder
		self.pushbutton_roadfile = QPushButton('Select', self)
		self.pushbutton_roadfile.resize(50,35)
		self.pushbutton_roadfile.move(425, 250) 
		self.pushbutton_roadfile.adjustSize()
		
		#push button_output folder text alignment
		self.namelabel_roadfile = QLabel(self)
		self.namelabel_roadfile.setText('Select Road File:')
		self.line_roadfile = QLineEdit(self)
		self.line_roadfile.move(200, 250)
		self.line_roadfile.resize(200, 32)
		self.namelabel_roadfile.move(10, 250)
		self.namelabel_roadfile.adjustSize()
			
		#push button for selection of output folder
		self.pushbutton_outfolder = QPushButton('Select', self)
		self.pushbutton_outfolder.resize(50,35)
		self.pushbutton_outfolder.move(425, 350) 
		self.pushbutton_outfolder.adjustSize()
		
		#push button_output folder text alignment
		self.namelabel_outfolder = QLabel(self)
		self.namelabel_outfolder.setText('Output Folder:')
		self.line_outfolder = QLineEdit(self)
		self.line_outfolder.move(200, 350)
		self.line_outfolder.resize(200, 32)
		self.namelabel_outfolder.move(10, 350)
		self.namelabel_outfolder.adjustSize()
		
		#push button for generate button
		self.pushbutton_generate = QPushButton('Generate' ,self)
		self.pushbutton_generate.resize(50,50)
		self.pushbutton_generate.move(225, 450) 
		self.pushbutton_generate.adjustSize()

