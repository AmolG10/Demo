import sys
from PySide6.QtWidgets import QApplication
from svgt_controller import SvgtController
from svgt_view import databasebasescenario,display_basescenarions_alert

if __name__ == "__main__":
    App =QApplication(sys.argv)
    
    basescenarions_alert = databasebasescenario()

    if basescenarions_alert == True:
        display_basescenarions_alert()
        raise SystemExit()
    else:
        data =SvgtController()

    sys.exit(App.exec())
