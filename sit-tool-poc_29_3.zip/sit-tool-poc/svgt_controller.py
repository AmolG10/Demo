from svgt_model import SvgtModel
from svgt_view import SvgtView
from svgt_view import display_variation_status
from PySide6.QtWidgets import QFileDialog
import svgt_reqs_variations_extractor
import svgt_config as svgtconfig

class SvgtController:
	
 def __init__(self):
    self.view=SvgtView()
    self.model=SvgtModel()
    self.vehicle_name=""
    self.category_type=''
    self.l2_req_file=''
    self.selected_road_file=''
    self.selected_output_folder=''
    #self.view.pushbutton_inputfile.clicked.connect(self.provide_scenario_des_file_path)
    self.view.pushbutton_roadfile.clicked.connect(self.provide_road_file_path)
    self.view.pushbutton_outfolder.clicked.connect(self.provide_output_path)
    self.view.pushbutton_generate.clicked.connect(self.click_generate)
    self.view.pushbutton_L2_inputfile.clicked.connect(self.provide_L2_req_file_path)
    #self.view.pushbutton_reqcsvextract.clicked.connect(self.click_reqcsvextract)
    self.view.combo_box_Vehtype.currentTextChanged.connect(self.insert_vehicle_name)
    self.view.combo_box_category_type.currentTextChanged.connect(self.category_selection)
    #self.view.pushbutton_inputfile.clicked.connect(self.provide_scenario_des_file_path)
    
 def insert_vehicle_name(self, vehicle_name):
    if vehicle_name:
       self.model.get_vehicle_name(vehicle_name)
       self.vehicle_name=vehicle_name
    else:
       print("select vehicle name")
       
 def category_selection(self, category_type):
    if category_type:
       self.Testrun_file_path=self.model.L2_selected_category(category_type)
       self.category_type=category_type
    else:
       print("select category Type")      
       
 def provide_road_file_path(self):
    road_file , check = QFileDialog.getOpenFileName(None, "QFileDialog.getOpenFileName()","", "All Files (*);;Python Files (*.py);;Text Files (*.txt)")
    self.view.line_roadfile.setText('{}'.format(road_file))
    if road_file:
       self.selected_road_file=self.model.get_road_file(road_file)
    else:
       print("select Road file")
    
 def provide_scenario_des_file_path(self):
    Infile , check = QFileDialog.getOpenFileName(None, "QFileDialog.getOpenFileName()","", "All Files (*);;Python Files (*.py);;Text Files (*.txt)")
    self.view.line_inputfile.setText('{}'.format(Infile))
    folder_path=Infile
    if folder_path:
       self.model.get_data_from_scenario_description(folder_path)
       self.model.check_selected_category()
    else:
       print("select scenario description file")
       
 def provide_L2_req_file_path(self):
    Infile , check = QFileDialog.getOpenFileName(None, "QFileDialog.getOpenFileName()","", "All Files (*);;Python Files (*.py);;Text Files (*.txt)")
    self.view.line_L2_inputfile.setText('{}'.format(Infile))
    folder_path=Infile
    if folder_path:
       self.l2_req_file=folder_path
    else:
       print("select L2 requirement input file")
       
 def provide_output_path(self):
    output_path = str(QFileDialog.getExistingDirectory())
    self.view.line_outfolder.setText('{}'.format(output_path))
    if output_path:
       self.model.get_output_path_from_ui(output_path)
       self.selected_output_folder=output_path
    else:
       print("select output folder")
 
 '''def click_generate(self):
    status_flag=self.model.create_variations()
    #print(status_flag)
    if status_flag==True:
       display_variation_status("Variation Creation is Successful")'''

 def click_generate(self):
    req_csv_file_name = self.l2_req_file
    category = self.category_type
    #status_flag, output_df1_vars=self.model.get_req_csv_extract(req_csv_file_name,category,self.vehicle_name,self.Testrun_file_path,self.selected_road_file,self.selected_output_folder)
    #print(status_flag)
    status_flag, output_df1_vars=self.model.get_req_csv_extract(req_csv_file_name,category,self.selected_output_folder)
    if status_flag==True:
       display_string = "L2 requirement extraction is Successful. Check folder " + svgtconfig.output_var_path
       display_variation_status(display_string)

