import pandas as pd
from openpyxl import load_workbook
from pprint import pprint
import os
import svgt_config as svgtconfig
from svgt_config import uc_catagory_list as uc_category_list
#from svgt_model import SvgtModel


def get_req_csv_as_df(req_csv_file_name):
    req_csv_df = pd.read_csv(req_csv_file_name)
    # TBD - replace all blanks in df with '-' . not imp. do it in case of any issues in data processing.
    Row = req_csv_df.shape[0]  # finding total rows
    Col = req_csv_df.shape[1]  # finding total columns
    #pprint(req_csv_df)
    return req_csv_df

def get_filtered_category_df(req_csv_df, category):
    df_UC_BODY_HEAD_TAG = pd.DataFrame()
    for L2_category_name in list(req_csv_df.groupby('UC_BODY_HEAD_TAG').groups.keys()):   
        #print(i)
        if L2_category_name == category:
            mask_UC_BODY_HEAD_TAG = req_csv_df['UC_BODY_HEAD_TAG'] == L2_category_name
            df_UC_BODY_HEAD_TAG = req_csv_df[mask_UC_BODY_HEAD_TAG]
            Row = df_UC_BODY_HEAD_TAG.shape[0]  # finding total rows
            Col = df_UC_BODY_HEAD_TAG.shape[1]  # finding total columns
            #pprint(df_UC_BODY_HEAD_TAG)
            return df_UC_BODY_HEAD_TAG

#populate values in output_df from filtered cat_df as variation row
def get_variation_row_df_from_filtered_cat_df(df_UC_BODY_HEAD_TAG):
    catparamvaluelist_master = []
    catparamvaluelist=[]
    catparamnameslist_master = []
    Count_Row=[]
    
    for row in range(0, df_UC_BODY_HEAD_TAG.shape[0]):
        for par_num in range(4, 19):            #UC_PAR0_NAME ... UC_PAR15_NAME
            param_name = (df_UC_BODY_HEAD_TAG.iloc[row, par_num])
            if param_name not in catparamnameslist_master:
                if param_name != '-':
                    catparamnameslist_master.append(param_name)
                    param_name = '-'

        for par_num in range(23, len(catparamnameslist_master) + 23):               #UC_PAR0_VAL .. UC_PAR15_VAL
            param_value = (df_UC_BODY_HEAD_TAG.iloc[row, par_num])
            catparamvaluelist.append(param_value)
            param_value = '-'

        catparamvaluelist_master.append(catparamvaluelist)
        catparamvaluelist = []
        #Count_Row.append('R_' + str(row + 1))

    variation_row_df = pd.DataFrame(data=catparamvaluelist_master, columns=catparamnameslist_master)
     #below is additional info for input format. It is not commented code. retain this for reference only.
     # data=[[0,1,2,3,4,5,6,7],[7,6,5,4,3,2,1,0]],
    #index=Count_Row,                         # index=['R_1','R_2'],

    #pprint(variation_row_df)
    return variation_row_df

def retain_variable_params(output_df):
    output_df_col_name_list = output_df.columns.tolist()
    drop_col_list = []
    for col_name in output_df_col_name_list:
        if col_name not in svgtconfig.ucparam_consider:
            drop_col_list.append(col_name)
    #print(drop_col_list)
    output_df1_vars = output_df
    output_df1_vars.drop(drop_col_list, axis=1, inplace=True)
    output_df1_vars.drop_duplicates(subset=None,keep='first', inplace=True)
    #return output_df1_vars
    output_df_5_rows=output_df1_vars.head(5)
    return output_df_5_rows
    
def create_combined_excel_sheet(csv_file_name,var_extract_filename):
    excel_file_name=os.path.join(svgtconfig.output_var_path,'Retained.xlsx')
    work_book=load_workbook(excel_file_name)
    writer = pd.ExcelWriter(excel_file_name, engine='openpyxl')
    writer.book=work_book
    #var_excel_filename=os.path.join(svgtconfig.output_var_path,writer) 
    pd.read_csv(var_extract_filename).to_excel(writer,csv_file_name)
    writer.save()
 
'''   
def get_req_csv_extract(req_csv_file_name,category_type,vehicle_name,Testrun_file_path,selected_road_file,selected_output_folder):
    category_list=[]
    status_flag = False
    print("L2_Use_Case_Catalog extraction in progress")
    #TBD - once req_csv_file_name,category params are received correctly then remove hardcoded values
    #req_csv_file_name = os.path.join(svgtconfig.svgt_root_path, "Input","L2_Use_Case_Catalog_EBA_2018_ARS540BW11_2022_02_17__03_55_09.csv")
    req_csv_df = get_req_csv_as_df(req_csv_file_name)

   
    if "All" == category_type:
       category_list= uc_category_list
    else:
       category_list.append (category_type)
    for category in category_list:
        category_name=category
        df_UC_BODY_HEAD_TAG = get_filtered_category_df(req_csv_df,category_name)
        output_df1 = get_variation_row_df_from_filtered_cat_df(df_UC_BODY_HEAD_TAG)
        output_df1_vars = retain_variable_params(output_df1)
        csv_file_name = category + "_UC_PAR_NAME_retained.csv"
        var_extract_filename = selected_output_folder+str(csv_file_name)  # create complete variation file path
        output_df1_vars.to_csv(var_extract_filename)
        #create_combined_excel_sheet(csv_file_name,var_extract_filename)
        svgt_model_obj=SvgtModel()
        svgt_model_obj.get_l2_req_df(category_name,output_df1_vars,vehicle_name,Testrun_file_path,selected_road_file,selected_output_folder)
        status_flag = True
        
    return status_flag, output_df1_vars
'''