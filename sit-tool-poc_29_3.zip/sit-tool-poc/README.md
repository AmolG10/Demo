# SVGT Tool POC

**Python SW and required python packages installation**:

Make sure the following SW/packages are installed in your system

1. Set up Python version3.6 or greater than 3.6

2. pip install pandas
	
3. Install python pyside packages as mentioned below:

	3.1. create virtual environment

		python -m venv env
		Run batch for activating the environment: env\Scripts\activate.bat

	3.2. install below mentioned Python packages

		pip install pyside6
		
	3.3. Check python version
			python
		
	3.3. Import Pyside6
	
	3.4. Check Pyside version : pyside6.__version__
	
	3.5. https://doc.qt.io/qtforpython/quickstart.html
				
4. How to generate variations:
	
	4.1. Select Vehicle type

	4.2. Select scenario description input file

	4.3. Select Road type file

	4.4. Select output folder(generated test run file will be stored)

	4.5. Press generate button.
	
	4.6. Test run variations shall be created in selected output folder.

POC for basic operations in SVGT tool

**Repo info**:
- **database** -  database folder containing:   
- **db_testrun** - base testrun / use case / scenario files  
- **db_road** - road files  
- **db_vehicle** - vehicle files  
- **input** - sample scenario definition input file(s)  
- **output** - container for this tool created variation testrun files  
  
main.py - main entry  
  
_Model files_:  
svgt_config.py  
svgt_model.py  
svgt_var_param_format.py  
svgt_testrun_writer.py  
  
_View files_:  
svgt_view.py  
  
_Controller files_:  
svgt_controller.py  
  
###execution info:  
below command (optional) can be used for execution.  
'**python3 -X pycache_prefix=../bytecodes main.py**'  
where:  
**bytecodes** is a folder one level up from  main.py path.  
**pycache_prefix** option moves "compiled bytecode" / *.pyc files 
that gets created in \__pycache__\ folder out of source code directory structure.
for more info refer [pycache_prefix](https://howchoo.com/python/python-pycache-prefix)
