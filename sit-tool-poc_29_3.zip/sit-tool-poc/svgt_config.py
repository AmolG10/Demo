
#TBD - as of now this file contains 'tentative' config params. this file consolidates all config constants / hardcoded stuffs for single point code change.
#params which need customization capability without causing code change, move them into non-code config files. like
#uc_catagory_list, category_testrun_dict, cmparam_masterlist, ucparam_cmparam_dict

import os
import pandas as pd

#svgt project root path
svgt_root_path = os.path.dirname(os.path.realpath('__file__'))

#output variation testrun files dir path
#TBD - for every execution, create a dir under output as timestamp to store variation files
#TBD - create timestamp dir in var_testrun_filename (line 147) from svgt_testrun_writer.py
output_var_path = os.path.join(svgt_root_path, 'output')

#unused
#database files  dir path
db_path = os.path.join(svgt_root_path, 'database')

#unused
#base testrun / use case / scenario files database dir path
db_testrun_path = os.path.join(db_path, 'db_testrun')

#unused
#road files database dir path
db_road_path = os.path.join(db_path, 'db_road')

#unused
#vehicle files database dir path
db_vehicle_path = os.path.join(db_path, 'db_vehicle')

#unused
#output log files dir path
#TBD - for every execution, create a log file as timestamp.log to record info (all input, temp and output info)
#timestamp folder under output dir and timestamp.log should give sufficient info needed for debuging / recreate issue / investigation analysis purpose in case of errors
output_log_path = os.path.join(svgt_root_path, 'log')

#unused
#TBD - auto populate it through program - yyyymmddhhmmss
timestamp = "get invocation timestamp"


#base use case / scenario category list
uc_catagory_list=['CCRs','CCRm','CCRb','CBLA','CBFA','CCLTA','CBNA','CBNAO','CBOC','CCSC','CCSCFB','CMBLm','CMSC','CPLA','CPFA','CPNA','CCSCST','CCSCSIE','CCSCTCT','CCSCOTL','CCSCO','CCSCMT','CCSCTIEF','CCSCTiRA','CCSCTTSAL']
'''
uc_catagory_list=['CBFA','CBLA','CBLCE','CBLTC','CBLTO','CBNA','CBNAO','CBOC','CBRTC','CBRTO','CBSTC','CCAmCT','CCBTL','CCCET','CCCEWC','CCCR',
'CCCTWC','CCLCOT','CCLTA','CCLTAO','CCLTBT','CCLTLTT','CCLTOPR','CCLTRTT','CCR','CCRTA','CCRb','CCRm','CCRs','CCSALbs','CCSALn',
'CCSC','CCSCBT','CCSCDE','CCSCDO','CCSCECT','CCSCFB','CCSCMT','CCSCO','CCSCOTL','CCSCPF','CCSCPN','CCSCSC','CCSCSIE','CCSCST',
'CCSCTCT','CCSCTIEF','CCSCTIEN','CCSCTOE','CCSCTTSAL','CCSCTiRA','CCSVALbs','CCSVALn','CCTEL','CCTFR','CCTTERC','CCTTERO',
'CDGSB','CDGSP','CMBLb','CMBLm','CMBRs','CMSC','CPF','CPFA','CPFAO','CPFC','CPFO','CPLA','CPLAE','CPLTO','CPNA','CPNAGN',
'CPNC','CPNCO','CPNDOC','CPNO','CPOC','CPRTO','CPSA','CPSTA','CPTRA','CPcsb','CSBDG','CSBUG','CSFA','CSPDG','CSPUG',
'CSTP','CUGSB','CUGSP','CVFA','TNCBS','TNCCRb','TNCPS','TNCSTPRLOP','TNCSTPROP','TNCVLTAP','TNCVRm','TNCVRs']
'''

vehicle_name_list=['BMW_5_BMWBrake','BMW_5_FSF500','Conti_Vehicles_CMC','TBD3']

#unused
#key value pairs to hold base use case / scenario categories and relevant testrun file names
#TBD - obtain base use case / scenario testrun files for all cases
category_base_testrun_dict = {'CCRs':'CCRs_50p_vEgo_30kph_vTar_0kph_ID_818',
                         #'CCSCTIE':'CCSCTIE_vEgo_10kph_vTar_10kph_ID_45812',
                         'CCLTA':'CCLTA_25p_Vego_20kph_Vtar_30kph_r14_75_ID_102860',
                         'CCRm':'CCRm_m50p_vEgo_35kph_vTar_20kph_FCW_ID_12932',
                         'CCRb':'CCRb_50kph_40m_6mpss_ID_397',
                         'CBFA':'CBFA_20p_vEgo45kph_vTar_20kph_ID_13954',
                         #'CBLASC':'CBLASC_p25p_vEgo_50kph_vTar_15kph_ID_49287',
                         'CBLA':'CBLA_25p_vEgo_55kph_vTar_15kph_ID_12859',
                         'CBNA':'CBNA_25p_vEgo_60kph_vTar_15kph_ID_13629',
                         'CBNAO':'CBNAO_50p_vEgo_10kph_vTar_10kph_ID_021',
                         #'CBOA':'CBOA_50p_vEgo_10kph_vTar_15kph_ID_024',
                         'CBOC':'CBOC_50p_vEgo_25kph_vTar_15kph_135deg_ID_013',
                         #'CCOCSA':'CCOCSA_vEgo_25kph_vTar_20kph_ID_58033',
                         'CCSC':'CCSC_vEgo_0kph_vTar_50kph_ID_95105',
                         'CCSCFB':'CCSCFB_vEgo_10kph_vTar_5kph_ID_44968',
                         'CCSCMT':'CCSCMT_vEgo_10kph_vTar_5kph_45deg_ID_47121',
                         'CCSCO':'CCSCO_vEgo_30kph_vTar_40kph_90_deg_ID_49259',      #Traffic.0.Init.v :parameter is not present in testrun file
                         'CCSCOTL':'CCSCOTL_Vego_10kph_Vtar_10kph_ID_45876',         #need to check v_target
                         'CMBLm':'CMBLm_p25p_vEgo_55kph_vTar_20kph_FCW_ID_15170',    #ovrlap parameter is not present in ts
                         'CMSC':'CMSC_vEgo_10kph_vTar_10kph_ID_37697',
                         'CPFA':'CPFA_25p_vEgo_10kph_vTar_8kph_ID_12282',
                         'CPLA':'CPLA_50p_vEgo_15kph_vTar_5kph_ID_6114',
                         #'CPLASC':'CPLASC_p25p_vEgo_50kph_vTar_5kph_ID_48718',
                         'CPNA':'CPNA_25p_vEgo_60kph_vTar_5kph_ID_15317',
                         'CCSCSIE':'CCSCSIE_vEgo_10kph_vTar_10kph_90_deg_2mpss_ID_44280',
                         'CCSCST':'CCSCST_vEgo_10kph_vTar_0kph_IP_A_ID_47010',
                         'CCSCTCT':'CCSCTCT_vEgo_10kph_vTar_10kph_r10_ID_46681',
                         'CCSCTIEF':'CCSCTIEF_vEgo_10kph_vTar_10kph_ID_100805',     #need to check v_target
                         'CCSCTiRA':'CCSCTiRA_vEgo_10kph_vTar_10kph_r10_ID_46773',
                         'CCSCTTSAL':'CCSCTTSAL_vEgo_10kph_vTar_10kph_r10_ID_46828'
                         }

#usage. remove after refactoring check_selected_category()
#testrun = svgt_config.category_base_testrun_dict.pop(category)

#unused
#UC_PAR_NAME  and UC_VARPC_NAME
UC_PAR_NAME_master_param_list=['target', 'v_ego', 'overlap', 'v_target', 'brake robot', 'ego trajectory', 'target trajectory', 'sight obstruction', 'impact position', 'target trajectory (Car to Bicycle Turning', 'start of cutting maneuver', 'lange change duration', 'lateral displacement between ego and target at start of lane change', 'minimum distance', 'Ego_Impact_Position', 'Target_Impact_Position', 'Ego_Impact_Position_front ; Ego_Impact_Position_latteral', 'critical_target_impact_position ; non_critical_target_impact_position', 'critical_v_target ; non_critical_v_target', 'lateral distance', 'rotation', 'ego vehicle type', 'load condition', 'load distribution', 'driver preference for warning time', 'test start', 'road condition', 'light conditions', 'ego_trajectory', 'v_target_at_start', 'distance', 'target acceleration', 'target1_trajectory', 'target2_trajectory', 'target1_minimum_distance', 'target2_minimum_distance', 'target rotation', 'light condition', 'hitpoint', 'target trajectory (Car to Pedestrian Turning', 'steel trench plate', 'steel trench plate position']

#TBD - confirm correctness of below lists with conti
ucparam_consider = ['v_ego', 'overlap', 'v_target', 'rotation','distance','target acceleration']
#ucparam_drop = ['target', 'brake robot', 'ego trajectory', 'target trajectory', 'sight obstruction', 'impact position', 'target trajectory (Car to Bicycle Turning', 'start of cutting maneuver', 'lange change duration', 'lateral displacement between ego and target at start of lane change', 'minimum distance', 'Ego_Impact_Position', 'Target_Impact_Position', 'Ego_Impact_Position_front ; Ego_Impact_Position_latteral', 'critical_target_impact_position ; non_critical_target_impact_position', 'critical_v_target ; non_critical_v_target', 'lateral distance', 'ego vehicle type', 'load condition', 'load distribution', 'driver preference for warning time', 'test start', 'road condition', 'light conditions', 'ego_trajectory', 'v_target_at_start', 'target1_trajectory', 'target2_trajectory', 'target1_minimum_distance', 'target2_minimum_distance', 'target rotation', 'light condition', 'hitpoint', 'target trajectory (Car to Pedestrian Turning', 'steel trench plate', 'steel trench plate position']



#TBD - rewrite check_selected_category() using config or move it to config and set Testrunfilepath (or input_base_testrun_path
#or create set_input_base_testrun_path(category)
#input_base_testrun_path = input_base_testrun_db_path + "/" + category_base_testrun_dict.pop(input_category)
#input_base_testrun_path = input_base_testrun_db_path + "/" + svgt_config.category_base_testrun_dict.pop(input_category)

#unused
#CarMaker UAQ (User Accessible Quantities) parameters / signals master list
#TBD - extend this list to include all signals that appear in testrun files and for which variation creation will be supported by svgt
#NOTE - this list does not mean exhaustive list of all carmaker signals as not every signal can be varied through svgt
#NOTE - do not confuse this list with 'fixed' & 'variable' types found in scenario definition input file. 'fixed' param in one input file can be 'variable' in another one
cmparam_masterlist = ["Vehicle",
                "DrivMan.Init.Velocity",
                "DrivMan.0.LongDyn",
                "DrivMan.1.LongDyn",
                "Traffic.T00.ty",
                "Traffic.0.Init.Orientation",
                "TBD",
                "TBD",
                "TBD"]

#unused
#base use case / scenario params from requirements to CarMaker UAQ parameters / signals mapping - key, value pairs  dictionary
#TBD - extend this list to include all params that appear in req csv files and for which variation creation will be supported by svgt
ucparam_cmparam_dict = {'v_ego':['DrivMan.Init.Velocity','DrivMan.0.LongDyn','DrivMan.1.LongDyn'],
                        'overlap':['Traffic.T00.ty'] ,
                        'rotation':['Traffic.0.Init.Orientation'],
                        'v_target':['Traffic.0.Init.v'],
                        'distance':['Eval Time <= 5.0 ? Traffic.T00.tx'],
                        'target acceleration':['Eval Time > 5.0 ? Traffic.T00.tx']}

#unused
#create new df for scenario  definition params input file rows. unused
scenario_df_cols=['ScenarioID', 'ReqID', 'Category','ParameterDescription','Parameter','ParameterType','Value','Unit','CMParam','Min','Max','Step','AppendValue']
scenario_df = pd.DataFrame(columns=scenario_df_cols)

#unused
#create new df for variation range params . unused.
variation_range_df_cols=['Min', 'Max', 'Step']
variation_range_df = pd.DataFrame(columns=variation_range_df_cols)

#unused
#create new df for variation params . unused.
variation_df_cols=['ScenarioID','Category','Parameter','Unit','CMParam','VarNum','VarVal']
variation_df = pd.DataFrame(columns=variation_df_cols)

#unused
#create new df for requirement csv params . unused.
reqparam_df_cols=['UC_INDEX','UC_SCTAG_ID','UC_SCTAG_NAME','UC_PAR_ID_NAME','UC_PAR0_NAME','UC_PAR1_NAME','TBD1','TBD2']
reqparam_df = pd.DataFrame(columns=reqparam_df_cols)




