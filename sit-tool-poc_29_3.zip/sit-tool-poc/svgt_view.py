from PySide6 import QtCore, QtGui,QtWidgets
from PySide6.QtWidgets import QFileDialog, QMainWindow, QWidget, QLabel, QLineEdit,QComboBox,QPushButton,QMessageBox
import sys
import os
from PySide6.QtGui import*
from PySide6.QtWidgets import *
from PySide6.QtCore    import * 
#from svgt_model import SvgtModel

def databasebasescenario():

	fileDir = os.path.dirname(os.path.realpath('__file__'))
	base_scenarios_path = os.path.join(fileDir, 'database', 'db_testrun')
	relative_path_base_scenarios = os.path.relpath(base_scenarios_path, fileDir)

	# checking if the directory is empty  

	if len(os.listdir(relative_path_base_scenarios) ) == 0:
		return True
	else:
		return False	

def display_basescenarions_alert():

	base_scenarios_alert = QMessageBox()
	base_scenarios_alert.setWindowTitle("BaseScenarios")
	base_scenarios_alert.setText("Directory is Empty ! Please place the base scenario files")
	base_scenarios_alert.exec()
    
def display_variation_status(string):

	created_variation_status = QMessageBox()
	created_variation_status.setWindowTitle("    Variation Status    ")
	created_variation_status.setText(string)
	created_variation_status.exec()    
    
class SvgtView(QMainWindow):

	def __init__(self):    #initilization method
		QMainWindow.__init__(self)
		vehicle_list=[]
		category_list=[]
		input_file=[]
		self.selected_input_file=""
		self.vehicle_name=""
        # setting title
		self.setWindowTitle("SVGT")  
        # setting geometry
		self.setGeometry(500, 500, 700, 700) #dimension of  MainWindow
	
        # calling method
		self.create_ui()
	
        #showing all the widgets
		self.show()
		#checkboxDemo.show()
    # method for widgets
	def create_ui(self):
		#creating Vehicle type combo box widget
		self.combo_box_Vehtype = QComboBox(self)
		self.namelabel_Vehtype = QLabel(self)
		self.namelabel_Vehtype.setText('Select Vehicle Type:')
		self.namelabel_Vehtype.resize(200,32)
		self.namelabel_Vehtype.move(10, 50) #(10,50)
		
		# setting Vehtype geometry of combo box
		self.combo_box_Vehtype.setGeometry(200, 55, 500, 50) # creation of box along with dimension 
		# list of vehicles
		vehicle_list = ["Demo_Car","Conti_Vehicles_CMC/BMW_5_FSF500", "BMW_5_BMWBrake ","Vehicle3", "Vehicle4"]

		# making it editable
		self.combo_box_Vehtype.setEditable(True) #1st edit combobox
		
		# adding list of items to combo box
		self.combo_box_Vehtype.addItems(vehicle_list) # creation of vehicle Type dropdown
        
		# adjusting the size according to the maximum sized element
		self.combo_box_Vehtype.adjustSize()
        
        #creating category type combo box widget
		self.combo_box_category_type=QComboBox(self)
		self.namelabel_category_type=QLabel(self)
		self.namelabel_category_type.setText('Category Type:')
		self.namelabel_category_type.resize(200,125)#(1500,125)
		self.namelabel_category_type.move(10,50)
        
        # setting CategoryType geometry of combo box
		self.combo_box_category_type.setGeometry(200, 100, 500, 50)
        
        #List of CategoryType
		category_list=['CCRs','CCRm','CCRb','CBLA','CBFA','CCLTA','CBNA','CBNAO','CBOC','CCSC','CCSCFB','CMBLm','CMSC','CPLA','CPFA','CPNA','CCSCST','CCSCSIE','CCSCTCT','CCSCOTL','CCSCO','CCSCMT','CCSCTIEF','CCSCTiRA','CCSCTTSAL','All']
        
        # making it editable
		self.combo_box_category_type.setEditable(True)
        
        # adding list of items to combo box
		self.combo_box_category_type.addItems(category_list)
        
        # adjusting the size according to the maximum sized element        
		self.combo_box_category_type.adjustSize()
        
         #selection of Input file
		'''self.combo_box_selection_of_input_file_type=QComboBox(self)
		self.namelabel_selection_of_input_file_type=QLabel(self)
		self.namelabel_selection_of_input_file_type.setText('Input File Type:')
		self.namelabel_selection_of_input_file_type.resize(200,125)#(1500,125)
		self.namelabel_selection_of_input_file_type.move(10,95)
        
		self.combo_box_selection_of_input_file_type.setGeometry(200, 140, 500, 50)
        
		input_file=["SD file","L2 Usecase File"]
        
          # making it editable
		self.combo_box_selection_of_input_file_type.setEditable(True)
        
        # adding list of items to combo box
		self.combo_box_selection_of_input_file_type.addItems(input_file)
		#self.combo_box_selection_of_input_file_type.currentTextChanged.connect(self.insert_selection_of_input)
        # adjusting the size according to the maximum sized element        
		self.combo_box_selection_of_input_file_type.adjustSize()
        
        
		#push button for select SD file
        
		self.pushbutton_inputfile = QPushButton('Select', self)
		self.pushbutton_inputfile.resize(25,120)
		self.pushbutton_inputfile.move(425, 175) #(425,153)
		self.pushbutton_inputfile.adjustSize()
		
		#push button for select SD file text alignment
		self.namelabel_inputfile = QLabel(self)
		self.namelabel_inputfile.setText('Scenario Description Input File:')
		self.line_inputfile = QLineEdit(self)
		self.line_inputfile.move(200, 180)#(200,150)
		self.line_inputfile.resize(200, 32)
		self.namelabel_inputfile.move(10, 180)#(10,150)
		self.namelabel_inputfile.adjustSize()'''
            
        #push button for select L2 UsecCase file
		self.pushbutton_L2_inputfile = QPushButton('Select', self)
		self.pushbutton_L2_inputfile.resize(25,120)
		self.pushbutton_L2_inputfile.move(425, 150) 
		self.pushbutton_L2_inputfile.adjustSize()
		
		#push button for select L2 UseCase file text alignment
		self.namelabel_L2_inputfile = QLabel(self) 
		self.namelabel_L2_inputfile.setText('L2 UseCase Input File:')
		self.line_L2_inputfile = QLineEdit(self)
		self.line_L2_inputfile.move(200, 150)#Box moving (right left , up down)
		self.line_L2_inputfile.resize(200, 32)
		self.namelabel_L2_inputfile.move(10, 150)#text moving(right or left , up or down )
		self.namelabel_L2_inputfile.adjustSize()
        #new code
        
        #push button for selection of road file
		self.pushbutton_roadfile = QPushButton('Select', self)
		self.pushbutton_roadfile.resize(50,35)
		self.pushbutton_roadfile.move(425, 225)#(450,300) 
		self.pushbutton_roadfile.adjustSize()
  
		#push button_Road file text alignment
		self.namelabel_roadfile = QLabel(self)
		self.namelabel_roadfile.setText('Select Road File:')
		self.line_roadfile = QLineEdit(self)
		self.line_roadfile.move(200, 225)#(200,290) Box Moving(right or left , up or down)
		self.line_roadfile.resize(200, 32) # (200,32)Box size increse or decrease by( width , height)
		self.namelabel_roadfile.move(10, 225)#(10,295)text moving(right or left , up or down )
		self.namelabel_roadfile.adjustSize()
			
		#push button for selection of output folder
		self.pushbutton_outfolder = QPushButton('Select', self)
		self.pushbutton_outfolder.resize(50,35)
		self.pushbutton_outfolder.move(425, 300) 
		self.pushbutton_outfolder.adjustSize()
		
		#push button_output folder text alignment
		self.namelabel_outfolder = QLabel(self)
		self.namelabel_outfolder.setText('Output Folder:')
		self.line_outfolder = QLineEdit(self)
		self.line_outfolder.move(200, 300)
		self.line_outfolder.resize(200, 32)
		self.namelabel_outfolder.move(10, 300)
		self.namelabel_outfolder.adjustSize()
		
		#push button for generate button
		self.pushbutton_generate = QPushButton('Generate Variations' ,self)
		self.pushbutton_generate.resize(50,50)
		self.pushbutton_generate.move(225, 375) 
		self.pushbutton_generate.adjustSize()
'''
		#push button for generate button
		self.pushbutton_reqcsvextract = QPushButton('L2 req extract' ,self)
		self.pushbutton_reqcsvextract.resize(50,50)
		self.pushbutton_reqcsvextract.move(225, 500)
		self.pushbutton_reqcsvextract.adjustSize()
'''	
        
        
        