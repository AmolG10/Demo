import os
import pandas as pd
import openpyxl
import itertools
from enum import IntEnum
from pprint import pprint
'''class Parameter:
 def update_params(self, parameter = "", parametertype="", value= 0, unit= "", cmparam= "", min=0, max=0, step= 0):
        self.parameter = parameter
        self.parametertype = parametertype
        self.value = value
        self.unit = unit
        self.cmparam = cmparam
        self.min = min
        self.max = max
        self.step = step'''
        
class SvgtModel:

 def get_output_path_from_ui(self,path):
    self.output_path=path
       
 def get_vehicle_name(self,veh_name):
    self.vehicle_name= veh_name
    
 def get_road_file(self,road_file):
    self.selected_roadfile= road_file
    
 def get_data_from_scenario_description(self,input_file):
    self.df = pd.read_csv(input_file)
    self.Row = self.df.shape[0]  # finding total rows
    self.Col = self.df.shape[1]  # finding total columns
    
    # forward fill using previous value to fill in empty cells for below columns
    self.df['ScenarioID'] = self.df['ScenarioID'].ffill()
    self.df['ReqID'] = self.df['ReqID'].ffill()
    self.df['Category'] = self.df['Category'].ffill()

  
 def check_selected_category(self):
    catagory_list=['CCRs','CCRm','CCRb','CCSCTIE']
    for row in range(0, self.Row):
        excel_values = []
        excel_row_list = []
        for col in range(self.Col):
            excel_values = (self.df.iloc[row, col])
            if col >= 1:
                excel_row_list.append(excel_values)
        if excel_row_list[1] in catagory_list:
           self.category_name=excel_row_list[1]
           if self.category_name == 'CCRs':
             self.Testrunfilepath = "CCRs_50p_vEgo_30kph_vTar_0kph_ID_818"
           elif category_name == 'CCSCTIE':
             self.Testrunfilepath = "CCSCTIE_vEgo_10kph_vTar_10kph_ID_45812"
           else:
             print("category not present")
             
 def create_scenario_filename(self,ego_velocity_kph,overlap_value,rotation_value):
    self.create_file_name=str(self.output_path)+"/"+str(self.category_name)+"_"+str(overlap_value)+"p_vEgo_"+str(ego_velocity_kph)+"kph_vRot_"+str(rotation_value)+"_Deg_ID_7416"
   
 def create_scenario_file_using_base_usecase(self,filename):
    with open(filename, "r") as read_only:
        if os.path.isfile(self.create_file_name):
            print("File already existing")
        else:
            with open(self.create_file_name, "w") as output:
                for line in read_only:
                    output.write(line)

 def update_created_scenario_file(self,parameter_name,parameter_value):
    output_testrun_file = open(self.create_file_name, 'r+')
    content_lines = []
    for line in output_testrun_file:
            if parameter_name in line:
               if '=' in line:                
                    line_components = line.split('=')
                    if type(parameter_value) == str:
                        line_components[1] = parameter_value +'\n'
                    else:
                        line_components[1] = str(parameter_value) +'\n'
                    updated_line= "=".join(line_components)
                    content_lines.append(updated_line)
               else:
                 print(parameter_name,":parameter is not present in testrun file")
            else:
                    content_lines.append(line)

    output_testrun_file.seek(0)
    output_testrun_file.truncate()
    output_testrun_file.writelines(content_lines)
    
 def create_variations(self):
    #iterate over ScenarioID groups list - input file can have multiple scenario IDs
    for i in list(self.df.groupby('ScenarioID').groups.keys()):
        #create mask for ScenarioID to filter df to get rows only for specific ScenarioID
        mask_ScenarioID = self.df['ScenarioID'] == i
        df_for_ScenarioID = self.df[mask_ScenarioID]

        #copy only min, max and step columns into another df
        df_for_ScenarioID_3cols = df_for_ScenarioID[['Min', 'Max', 'Step']].copy()
        #increament Max by Step as range function needs it that way to work correctly
        df_for_ScenarioID_3cols['Max'] = df_for_ScenarioID_3cols['Max'] + df_for_ScenarioID_3cols['Step']

        #block to create range list to create variations
        variation_range_list = []
        for row in range(0, df_for_ScenarioID_3cols.shape[0]):
            #obtain mix, max and step for 1 row
            param_min = (df_for_ScenarioID_3cols.iloc[row, 0])
            param_max = (df_for_ScenarioID_3cols.iloc[row, 1])
            param_step = (df_for_ScenarioID_3cols.iloc[row, 2])
            # create range list for 1 row of df
            variation_range = [*range(param_min,param_max,param_step)]
            # append range list to create list of lists
            variation_range_list.append(variation_range)
            #print(param_min,param_max,param_step)

        print(variation_range_list)
        variations = list(itertools.product(*variation_range_list))
        #pprint(variations)

    # TBD -  split below onwards into separate method(s)#####################################                
                         
    class Percentage(IntEnum):
         OVERLAP_0_P=0
         OVERLAP_25_P=25
         OVERLAP_50_P=50
         OVERLAP_75_P=75
     
    #create values for overlap
    overlap_values_list = [0, "Car.ty-Car.Width_m/-4", "Car.ty-Car.Width_m/-2", "3*Car.ty-Car.Width_m/-4", "Car.ty-Car.Width_m"]
  
    for combination in variations:
        Driv_longdy=" Driver 1 0 "+ str(combination[0])
       
        self.create_scenario_filename(combination[0], combination[1], combination[2])
        self.create_scenario_file_using_base_usecase(self.Testrunfilepath)
        self.update_created_scenario_file('Vehicle ',self.vehicle_name)
        self.update_created_scenario_file('DrivMan.Init.Velocity', combination[0])
        self.update_created_scenario_file('DrivMan.0.LongDyn',Driv_longdy)
        self.update_created_scenario_file('DrivMan.1.LongDyn',Driv_longdy)
        
        if combination[1] == Percentage.OVERLAP_0_P:
            self.update_created_scenario_file('Traffic.T00.ty', overlap_values_list[0])
        elif combination[1] == Percentage.OVERLAP_25_P:
            self.update_created_scenario_file('Traffic.T00.ty', overlap_values_list[1])
        elif combination[1] == Percentage.OVERLAP_50_P:
            self.update_created_scenario_file('Traffic.T00.ty', overlap_values_list[2])
        elif combination[1] == Percentage.OVERLAP_75_P:
            self.update_created_scenario_file('Traffic.T00.ty', overlap_values_list[3])
        else:
            self.update_created_scenario_file('Traffic.T00.ty', overlap_values_list[4])

        rotation_value=' 0.0 0.0 -'+ str(combination[2])
        self.update_created_scenario_file('Traffic.0.Init.Orientation', rotation_value)