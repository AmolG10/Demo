import sys
from PySide6.QtWidgets import QApplication
from svgt_controller import SvgtController


if __name__ == "__main__":
    App =QApplication(sys.argv)
    data =SvgtController()
    sys.exit(App.exec())
    